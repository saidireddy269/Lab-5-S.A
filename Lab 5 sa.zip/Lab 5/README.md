## Hello World Django App
### How to run/start the app
First you'll need to clone this repository.
```git
git clone <REPO URL>
```
Then you need to have django installed on you machine. If not you can install django with the following command
``` 
pip install django
```
After installing django open the terminal in the project folder and run the following command to start the app
```
python manage.py runserver
```
This will start a development server at
```
http://127.0.0.1:8000/
```
To access the JSON response use the link provided to by the app load the above URL to your browser

